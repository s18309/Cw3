import java.util.HashMap;
import java.util.Random;

public class LanguagePerceptron {

        double alfa;
        double[] importance;
        double theta;
        String language;

        public LanguagePerceptron(double alfa, String language){
            this.alfa = alfa;
            this.importance = new double[26];
            this.language = language;


            Random random = new Random();

            for (int i = 0; i < importance.length; i++) {

                double tmpWar = random.nextDouble() * 10 - 5;
                importance[i] = tmpWar;

            }

            this.theta = random.nextDouble() * 10 - 5;
        }

        public int TrainingCheck(double[] p){
            double wynik = 0;

            for (int i = 0; i < p.length; i++) {
                wynik += p[i]*importance[i];
            }

            if(wynik >= theta){
                return 1;
            }else
                return 0;
        }

         public double TestCheck(double[] p){
             double wynik = 0;

             for (int i = 0; i < p.length; i++) {
                 wynik += p[i]*importance[i];
             }

             return 1/(1 + Math.pow(Math.E,-wynik));
        }

        public void learn(double[] p, int d_right, int y_wrong){
            theta =  theta + (-1 * alfa * (d_right - y_wrong));

            double[] tmpImportance = new double[importance.length];

            for (int i = 0; i < tmpImportance.length; i++) {
                tmpImportance[i] = importance[i] +  alfa * (d_right - y_wrong) * p[i];
            }

            importance = tmpImportance;

        }

        public void normalize(){

            double tmpValue = 0;

            for (int i = 0; i < importance.length; i++) {
                tmpValue += Math.pow(importance[i],2);
            }

            tmpValue = Math.sqrt(tmpValue);

            for (int i = 0; i < importance.length; i++) {
                importance[i] = importance[i]/tmpValue;
            }
        }

}
