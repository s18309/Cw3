import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

public class LanguageDataDeliverer {

    private InputStream inputStream;

    public void setInputStream(InputStream inputStream){
        this.inputStream = inputStream;
    }

    public HashMap<Character, Integer> countLetters() throws IOException {
        HashMap<Character,Integer> hashMap = new HashMap<>();
        int letter = inputStream.read();
        while(letter > 0) {
            if (letter >= (int) 'a' && letter <= (int) 'z')
                letter = letter - 32;

            if(letter >= (int) 'A' && letter <= (int) 'Z'){
                if ((hashMap.putIfAbsent((char) letter, 1) != null)) {
                    int oldValue = hashMap.get((char) letter);
                    hashMap.replace((char) letter, oldValue + 1);
                }

            }
            letter = inputStream.read();
        }
    return hashMap;
    }

    public HashMap<Character, Integer> countLetters(String value) throws IOException {
        HashMap<Character,Integer> hashMap = new HashMap<>();
        char [] letters = value.toCharArray();

        for (int i = 0; i < letters.length; i++) {
            int letter = letters[i];
            if (letter >= (int) 'a' && letter <= (int) 'z')
                letter = letter - 32;

            if (letter >= (int) 'A' && letter <= (int) 'Z') {
                if ((hashMap.putIfAbsent((char) letter, 1) != null)) {
                    int oldValue = hashMap.get((char) letter);
                    hashMap.replace((char) letter, oldValue + 1);
                }

            }
        }
        return hashMap;
    }
}

