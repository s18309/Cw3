import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {

        File dataDirectory = new File("katalog_na_dane");
        String [] languageDirectories = dataDirectory.list();
        ArrayList<LanguagePerceptron> languagePerceptrons = new ArrayList<>();
        LanguageDataDeliverer languageDataDeliverer = new LanguageDataDeliverer();

        double alfa = 0.1;

        for(int i = 0; i < languageDirectories.length; i++) {
            LanguagePerceptron tmpLanguagePerceptron = new LanguagePerceptron(alfa,languageDirectories[i]);
            languagePerceptrons.add(tmpLanguagePerceptron);
            File fileTmp = new File(dataDirectory.getPath() + "/" + languageDirectories[i]);
            String [] trainingFiles = fileTmp.list();

            for(int j = 0; j < trainingFiles.length; j++) {
                File fileTmp_2 = new File(fileTmp.getPath() + "/" + trainingFiles[j]);
                try {
                    FileInputStream fileInputStream = new FileInputStream(fileTmp_2);
                    languageDataDeliverer.setInputStream(fileInputStream);
                    double [] p = LetterVector.createVector(languageDataDeliverer.countLetters());
                    int result =  tmpLanguagePerceptron.TrainingCheck(p);
                    if(result != 1){
                        tmpLanguagePerceptron.learn(p,1,0);
                        System.out.println("Hello!");
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        languageDataDeliverer.setInputStream(System.in);

        for(LanguagePerceptron languagePerceptron : languagePerceptrons){
            languagePerceptron.normalize();
        }


       try{
           Scanner scanner = new Scanner(System.in);
           System.out.println("podaj wartosci argumentow");
           System.out.println("wcisnij ctrl-d aby zakonczyc");

           while(scanner.hasNextLine()) {
               double [] p = LetterVector.createVector(languageDataDeliverer.countLetters(scanner.nextLine()));
               p = LetterVector.normalize(p);
               double[] values = new double[languagePerceptrons.size()];
               int counter = 0;
               for( LanguagePerceptron languagePerceptron : languagePerceptrons){
                   values[counter] = languagePerceptron.TestCheck(p);
                   counter++;
               }

               int indexOfHighest = 0;
               for (int i = 0; i < values.length ; i++) {
                   if(values[i] > values[indexOfHighest])
                       indexOfHighest = i;
               }

               System.out.println(languagePerceptrons.get(indexOfHighest).language);
           }

       } catch (IOException e) {
           e.printStackTrace();
       }
    }
}
