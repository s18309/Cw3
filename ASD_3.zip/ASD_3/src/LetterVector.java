import java.util.HashMap;

public class LetterVector {

    public static double[] createVector(HashMap<Character, Integer> countedLetters){
        char letter = 'A';
        int counter = 0;
        double[] importance = new double [26];

        while(letter <= 'Z'){
            importance[counter] = countedLetters.getOrDefault(letter,0);
            letter++;
            counter++;
        }
        return importance;
    }

    public static double[] normalize(double[] importance){

        double tmpValue = 0;

        for (int i = 0; i < importance.length; i++) {
            tmpValue += Math.pow(importance[i],2);
        }

        tmpValue = Math.sqrt(tmpValue);

        for (int i = 0; i < importance.length; i++) {
            importance[i] = importance[i]/tmpValue;
        }

        return importance;
    }
}
