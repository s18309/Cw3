/**
 *
 *  @author Tarasewicz Urszula S18309
 *
 */

package zad1;


public class Tools {
}
